#!/bin/bashi

echo -e "USAGE: Keep this file in your results directory. \n then bash summarizescores.bash"

rm summary.txt

for i in gi50_screen_*
do
	echo $i
	sort -nrk4 $i/scores.txt | head -1 | gawk '{print $2"\t"$4"\t"$3}' >> summary.txt
done
#sed -i ':a;N;$!ba;s/\n/\t/g' summary.txt
sed -i 's/.json//g' summary.txt
sed -i 's/model_//g' summary.txt
