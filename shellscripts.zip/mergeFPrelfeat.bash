sed 's/,[^,]\+$//' train1919_1.txt > train1919_2.txt
awk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' train1919.txt train1919_2.txt
