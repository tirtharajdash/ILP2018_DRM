#!/bin/sh

for i in `cat datasets`
do
	echo -n $i ": "
	nmols=`cat $i"_mols.pl" | wc -l`
	npos=`cat $i"_class.pl" | grep pos | wc -l`
	nneg=`cat $i"_class.pl" | grep neg | wc -l`
	echo -n $nmols ", " $npos ", " $nneg ", "
	./stats_size.sh $i
done
