#!/bin/bash

for chemblprob in ../AB_Datasets/*
do
	echo $chemblprob
	
	if [ -d ./../regression_results/`basename $chemblprob` ]
	then
		rm -r ./../regression_results/`basename $chemblprob`
	fi
	mkdir ./../regression_results/`basename $chemblprob`

	for idataset in $chemblprob/*
	do
	    echo $idataset
		data=$(basename $idataset)
		echo $data
		mkdir $data
		cp $idataset/*.arff $data/
		python cleanandprepare.py
		sed -i 's/\"CHEMBL[^ ]*\",//g' $data/independent\_train.txt
		sed -i 's/\"CHEMBL[^ ]*\",//g' $data/independent\_test.txt
		mkdir models
		python train.py
		mv models $data/models
		if [ -d `basename $chemblprob`/$data ]
		then
		    rm -r ./../regression_results/`basename $chemblprob`/$data
		fi
		mkdir ./../regression_results/`basename $chemblprob`/
		mv $data ./../regression_results/`basename $chemblprob`/
	done
done
