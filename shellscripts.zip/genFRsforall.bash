#!/bin/bash

for file in *.csv
do
for mol in `cat $file`
do

cp ./`basename $file .csv`/$mol.pl ./TEMPORARY/$mol.pl

yap <<+
:- consult(main).
:- gen.
+

rm ./TEMPORARY/$mol.pl

mv results.pl ./`basename $file .csv`/$mol"_fr1.pl"
sort -u ./`basename $file .csv`/$mol"_fr1.pl" > ./`basename $file .csv`/$mol"_fr.pl"
rm ./`basename $file .csv`/$mol"_fr1.pl"
done

done
