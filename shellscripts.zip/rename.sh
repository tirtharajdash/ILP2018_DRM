#!/bin/sh

# /bin/rm dataset.pl *_atm_bond.pl *_class.pl *_mols.pl

for i in `cat mols`
do
	cat $i".txt" | grep -v class > $i"_atm_bond.pl"
	cat $i".txt" | grep class > $i"_class.pl"
	cat $i"_class.pl" | gawk -F, '{print $1}' | sed "s/class(/mol($i,/" | sed 's/$/)./' > $i"_mols.pl"
	echo $i | sed 's/^/dataset(/' | sed 's/$/)./' >> dataset.pl
	echo $i
done
