#!/bin/bash

rm traindsummary.txt
rm testdsummary.txt

for d in CHEMBL*
do
	for i in 1 2 3 4 5 6 7 8 9 10
	do
		cat $d/$i/train.arff | grep '@attribute ilp' | wc -l >> traindsummary.txt
		cat $d/$i/test.arff | grep '@attribute ilp' | wc -l >> testdsummary.txt
	done
done
