#!/bin/bash

if [ -d ALLDATASPLITS ]
then
    rm -r ALLDATASPLITS
fi
mkdir ALLDATASPLITS

for file in *.csv
do
    mkdir ALLDATASPLITS/`basename $file .csv`
    cp -rL `basename $file .csv`/ABFRsplits/* ALLDATASPLITS/`basename $file .csv`/;
done 
