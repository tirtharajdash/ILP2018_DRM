#!/bin/bash

# How to use this: Keep this file in the directory of your datasets
# USAGE: bash datasetprop.bash > summary.txt

echo -e "Dataset \t NumTrainFeats \t NumTestFeats \t TrainPos \t TrainNeg \t TestPos \t TestNeg"
for i in gi50_screen_*
do
    numtrain=`grep "@attribute ilp*" $i/holdout_redo/train.arff | wc -l`
    numtest=`grep "@attribute ilp*" $i/holdout_redo/test.arff | wc -l`
    numpostrain=`grep "1$" $i/holdout_redo/train.arff | wc -l`
    numnegtrain=`grep "0$" $i/holdout_redo/train.arff | wc -l`
    numpostest=`grep "1$" $i/holdout_redo/test.arff | wc -l`
    numnegtest=`grep "0$" $i/holdout_redo/test.arff | wc -l`
    echo -e $i "\t" $numtrain "\t" $numtest "\t" $numpostrain "\t" $numnegtrain "\t" $numpostest "\t" $numnegtest
done
