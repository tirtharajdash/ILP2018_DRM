#!/bin/sh

prefixdir="./../data/"

for i in `cat datasets50`
do

	echo $i

	/bin/rm atm_bond.pl two_dim.pl
	ln -s $prefixdir/$i/ab.pl atm_bond.pl
	ln -s  $prefixdir/$i/fr.pl two_dim.pl

	if [ -d output/$i ]
	then
		rm -r output/$i
	fi
	mkdir output/$i

	for split in 1 2 3 4 5 6 7 8 9 10
	#for split in 1
	do

		/bin/rm train.[fn] test.[fn] train_classes.pl test_classes.pl

		ln -s $prefixdir/$i/$split/train.pl train_classes.pl
		ln -s $prefixdir/$i/$split/test.pl test_classes.pl



		# Generate first-order features 
		./gen_features.sh train_classes.pl 5000 back.pl features.pl

		# Generate arff file
		./portray_features.sh train_classes.pl test_classes.pl features.pl 

		mkdir output/$i/$split

		mv train.arff output/$i/$split/train.arff
		mv test.arff output/$i/$split/test.arff
		mv features.pl output/$i/$split/features.pl
	done
done

