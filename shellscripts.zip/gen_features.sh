#!/bin/sh

DESCR="Generate first-order features by sampling"
USAGE="Usage: $0 classes_file sample_size background_file feature_file"

if [ "$#" -lt 4 ]; then
        echo "$DESCR"
        echo "$USAGE"
        exit 1
fi

/bin/rm train,[bfn]
cat $1 | gawk -F, '{print $1}' | sed "s/$/,pos)./" > train.f

cp $3 train.b

/bin/rm /tmp/features
yap <<+
consult(aleph).
read_all(train).
consult('gen_features.pl').
rand_gen_features(any,$2).
tell('/tmp/features'), show(features), told.
+
cat /tmp/features | grep -v "features from" > $4
