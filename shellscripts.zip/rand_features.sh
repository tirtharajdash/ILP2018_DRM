#!/bin/sh

# version=2

for i in 2 3 4 5 6 7 8 9 10
# for i in 1
do
	/bin/rm train.[fn]
	cat s$i/train.[fn] > train.f
yap <<+
consult(aleph).
read_all(train).
consult(rand_gen_features).
rand_gen_features(any,10000).
tell('/tmp/features'), show(features), told.
+
mv /tmp/features s$i/"b0_any_features.pl"
done
