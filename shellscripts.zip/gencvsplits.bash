#!/bin/bash

for file in *.csv
do

INPUT=~/ROSS_Feb2018/data/mqsar_splits/target\_id\_`basename $file .csv`.csv
OLDIFS=IFS
IFS=,

cp $INPUT ./splitinfo_`basename $file .csv`.txt

sed -i '1d' splitinfo_`basename $file .csv`.txt

#cat ~/ROSS_Feb2018/data/mqsar_splits/target\_id\_`basename $file .csv`.csv | sed '1d' | 

#if [ "$1" == "--help" ]; then
#  echo "Usage: cat sourcepath/split-info-file | sed '1d' | `basename $0`"
#  exit 0
#fi

if [ -d `basename $file .csv`/"ABFRsplits" ]
then
  rm -r `basename $file .csv`/"ABFRsplits"
fi
mkdir `basename $file .csv`/"ABFRsplits"

#if [ -d "ABFRsplits/splits" ]; then
#  rm -r "ABFRsplits/splits"
#fi
#mkdir "ABFRsplits/splits"

for DIR in {1..10}
do
  mkdir `basename $file .csv`/ABFRsplits/$DIR
done

#[ ! -f target_id_`basename $file .csv`.csv ]
while read f1 f2 f3 f4
#echo $f1 $f2 $f3 $f4
do
  #echo $f1 $f2 $f3 $f4
  cat `basename $file .csv`/$f2.pl | grep "activity(" >> `basename $file .csv`/ABFRsplits/$f1/test.pl
  cat `basename $file .csv`/$f2.pl | grep "atom(" >> `basename $file .csv`/ABFRsplits/ab.pl
  cat `basename $file .csv`/$f2.pl | grep "bond(" >> `basename $file .csv`/ABFRsplits/ab.pl
  cat `basename $file .csv`/$f2.pl | grep "compound_id(" >> `basename $file .csv`/ABFRsplits/extra.pl
  cat `basename $file .csv`/$f2.pl | grep "target(" >> `basename $file .csv`/ABFRsplits/extra.pl
  cat `basename $file .csv`/$f2\_fr.pl >> `basename $file .csv`/ABFRsplits/fr.pl
done < splitinfo_`basename $file .csv`.txt

for i in {1..10}
do
  for j in {1..10}
  do
    if [ $i -ne $j ]; then
      cat `basename $file .csv`/ABFRsplits/$j/test.pl >> `basename $file .csv`/ABFRsplits/$i/train.pl
    fi
  done
done

#tar -czvf `basename $file .csv`/ABFRsplits.tar.gz `basename $file .csv`/ABFRsplits/*

IFS=$OLDIFS

done
