rm metaqsarrmse.txt
cat datasets | while read line; do cat 180520_mqsar_deeplrn_fpFCFP4_rmse.csv | grep $line >> metaqsarrmse.txt; done;
sed -i 's/,/\t/g' metaqsarrmse.txt
