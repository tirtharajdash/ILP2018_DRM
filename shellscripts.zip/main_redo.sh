#!/bin/sh

prefixdir="/home/dell7810/tdash/qsar/czech"

for i in `cat datasets`
do

echo $i

/bin/rm mols.pl atm_bond.pl classes.pl two_dim.pl

ln -s $prefixdir/atm_bond/$i"_mols.pl" mols.pl
ln -s $prefixdir/atm_bond/$i"_atm_bond.pl" atm_bond.pl
ln -s $prefixdir/atm_bond/$i"_class.pl" classes.pl
ln -s $prefixdir/two_dim/$i"_fr.pl" two_dim.pl

if [ -d output/$i ] 
then
	/bin/rm -r output/$i/holdout_redo
else
	mkdir output/$i
fi

mkdir output/$i/holdout_redo

if [ -d output/$i/holdout ]
then
	cp output/$i/holdout/seed .
	cp output/$i/holdout/train_classes.pl .
	cp output/$i/holdout/test_classes.pl .
else
	nlines=`wc -l classes.pl | gawk '{print $1}'`
	ntrain=`echo "0.7*$nlines" | bc | gawk -F\. '{print $1}'`
	cat classes.pl | ~/tdash/qsar/shuffle > /tmp/shuffled
	~/tdash/qsar/rsplit $ntrain /tmp/shuffled train_classes.pl test_classes.pl > seed

fi

mv seed output/$i/holdout_redo


# Generate first-order features 
./gen_features.sh train_classes.pl 5000 back.pl features.pl

# Generate arff file
./portray_features.sh train_classes.pl test_classes.pl features.pl 


mv train.arff output/$i/holdout_redo
mv test.arff output/$i/holdout_redo
mv features.pl output/$i/holdout_redo
mv train_classes.pl output/$i/holdout_redo
mv test_classes.pl output/$i/holdout_redo
mv train.[fn] output/$i/holdout_redo
mv test.[fn] output/$i/holdout_redo

done

