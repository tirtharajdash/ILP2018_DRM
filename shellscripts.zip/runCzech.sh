#!/bin/sh

if [ -d ../DRM_results_abfr_simple_run1 ]
then
	rm -rf ../DRM_results_abfr_simple_run1
fi
mkdir ../DRM_results_abfr_simple_run1

for idataset in ./../Czech_ABFR_simple_run1/*
do
	data=$(basename $idataset)
	echo $data
	mkdir $data
	cp $idataset/holdout_redo/*.arff $data/
	python cleanandprepare.py
	mkdir models
	python train.py
	mv models $data/models
	mv $data ./../DRM_results_abfr_simple_run1/$data
done
