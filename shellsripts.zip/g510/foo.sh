#!/bin/sh

for mol in `cat HomoSapiensFiles`
do

cp ./../../data/HomoSapiens/pl/$mol.pl ./CHEMBL/$mol.pl

yap <<+
:- consult(main).
:- gen.
+

rm ./CHEMBL/$mol.pl

mv results.pl ./CHEMBL_FR/$mol"_fr1.pl"
sort -u ./CHEMBL_FR/$mol"_fr1.pl" > ./CHEMBL_FR/$mol"_fr.pl"
rm ./CHEMBL_FR/$mol"_fr1.pl"

done
