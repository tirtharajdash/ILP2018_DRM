#for f in ./mol_files/*.mol; do
#    babel -imol "$f" -omol2 $f.mol2
#done

#for f in ./mol_files/*.mol.mol2; do
#    mv "$f" "$(basename "$f" .mol.mol2)"
#done

#for f in ./mol_files/*.mol; do
#    rm $f
#done

for f in ./mol_files/*.mol.mol2; do
    mv "$f" "$(basename "$f" .mol.mol2)"
    cat "$f" | ./mol2pl A > $f.pl
    echo "$f.pl"
    #rm $f
done
mv *.pl pl_files/

