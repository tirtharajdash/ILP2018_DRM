#!/bin/bash

rm verifsummary.txt

for d in `cat DS50`
do
    n=`wc -l splitinfo\_$d.txt | gawk '{print $1}'`
    tr=`wc -l $d/1/train.pl | gawk '{print $1}'`
    ts=`wc -l $d/1/test.pl | gawk '{print $1}'`
    echo -e $d"\\t"$n"\\t"$tr"\\t"$ts >> verifsummary.txt
done
