#!/bin/bash

for d in 1 2 3 4 5 6 7 8 9 10
do	
	sed -i 's/\"CHEMBL39\", [0\+, 1\+]\+ 7.824$//g' $d/*.arff
	sed -i 's/\"CHEMBL39\", [0\+, 1\+]\+ 7.699$//g' $d/*.arff
	sed -i 's/\"CHEMBL39\", [0\+, 1\+]\+ 4.602$//g' $d/*.arff
	sed -i 's/\"CHEMBL39\", [0\+, 1\+]\+ 8.155$//g' $d/*.arff
	sed -i 's/\"CHEMBL86\", [0\+, 1\+]\+ 7.509$//g' $d/*.arff
	sed -i 's/\"CHEMBL86\", [0\+, 1\+]\+ 6.745$//g' $d/*.arff
	sed -i 's/\"CHEMBL86\", [0\+, 1\+]\+ 6.936$//g' $d/*.arff
    sed -i "/^$/d" $d/*.arff
done
