#!/bin/bash

for idataset in ./NCI_kopie_datasets/*
do
    dataset=$(basename $idataset)
    echo "Generating pl files for $dataset"
    x=$(wc -l < "$idataset")
    #echo $x

    for ((i=1;i<=$x;i++)) 
    do 
        sed -i $idataset -e "$i s/bond(/bond(m$i,/g"
    done

    for ((i=1;i<=$x;i++)) 
    do 
        sed -i $idataset -e "$i s/+/class(m$i,pos)./g" 
        sed -i $idataset -e "$i s/-/class(m$i,neg)./g" 
    done
    
    sed -i $idataset -e ':a;N;$!ba;s/)./).\n/g'
    sed -i $idataset -e ':a;N;$!ba;s/)$/)./g'
    sed -i $idataset -e 's/ //g'

    cp $idataset ./Data/$dataset.pl
    echo "....completed."

    echo "....Genererating Functional Groups and Rings."

yap <<+
:- consult(main).
:- gen.
+
    echo "........completed."
    echo ".... Storing results..."
    rm ./Data/$dataset.pl
    mv results.pl ./FR_files/$dataset"_fr.pl"
    echo "........completed."
    
done
