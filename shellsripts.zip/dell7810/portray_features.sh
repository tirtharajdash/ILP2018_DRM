#!/bin/sh

DESCR="Generate arff files"
USAGE="Usage: $0 train_classes_file test_classes_file feature_file"

if [ "$#" -lt 3 ]; then
        echo "$DESCR"
        echo "$USAGE"
        exit 1
fi


/bin/rm train.[fn] test.[fn]
# cat $1 | gawk -F, '{print $1}' | sed "s/$/,pos)./" > train.f
cp $1 train.f

# cat $2 | gawk -F, '{print $1}' | sed "s/$/,pos)./" > test.f
cp $2 test.f

yap <<+
consult(aleph).
read_all(train).
consult('portray_features.pl').
consult('$3').
tell('/tmp/train_pos.arff'), aleph_portray(train_pos), told.
tell('/tmp/test_pos.arff'), aleph_portray(test_pos), told.
+

/bin/rm train.arff test.arff
mv /tmp/train_pos.arff train.arff
cat /tmp/train_neg.arff | grep -v ilp | grep -v relfeatures | grep -v class | grep -v data | grep -v ^$ >> train.arff
mv /tmp/test_pos.arff test.arff
cat /tmp/test_neg.arff | grep -v ilp | grep -v relfeatures | grep -v class | grep -v data | grep -v ^$ >> test.arff

/bin/rm /tmp/*.arff 
