#!/bin/sh

mol=$1

/bin/rm /tmp/mols.txt /tmp/atoms_mols.txt

cat $mol"_mols.pl" | grep $mol | gawk -F, '{print $2}' | sed 's/).//' > /tmp/mols.txt

for i in `cat /tmp/mols.txt`
do
	/bin/rm /tmp/atoms_mol.txt
	cat $mol"_atm_bond.pl" | grep "bond($i," | gawk -F, '{print $2}'  >> /tmp/atoms_mol.txt
	cat $mol"_atm_bond.pl" | grep "bond($i," | gawk -F, '{print $3}'  >> /tmp/atoms_mol.txt
	sort -u /tmp/atoms_mol.txt | wc -l  >> /tmp/atoms_mols.txt
done
cat /tmp/atoms_mols.txt | ~/ashwin/bin/avg | gawk -F= '{print $3}'
