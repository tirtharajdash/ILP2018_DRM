#!/bin/bash

rm dssummary.txt
rm targetvalues.txt

for d in CHEMBL*
do
	for i in 1 2 3 4 5 6 7 8 9 10
	do
		wc -l $d/$i/independent_train.txt | gawk '{print $1}' >> dssummary.txt
		wc -l $d/$i/independent_test.txt | gawk '{print $1}' >> dssummary.txt

		cat $d/$i/independent_train.txt | gawk '{print $NF}' >> targetvalues.txt
		cat $d/$i/independent_test.txt | gawk '{print $NF}' >> targetvalues.txt
	done
done
