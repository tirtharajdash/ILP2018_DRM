#!/bin/bash

echo -e "USAGE: Keep this file in your results directory. \n then bash joinscores.bash"

if [ -d rmsescores ]
then
	rm -rv rmsescores
fi
mkdir rmsescores
rm rmsesummary.txt

for i in CHEMBL*
do
	echo $i
	#rm /tmp/2.txt
	join -j1 -t $'\t' $i/1/scores.txt $i/2/scores.txt > /tmp/2.txt
	
	for j in 3 4 5 6 7 8 9 10
	do
		k=`expr $j - 1`
		join -j1 -t $'\t' /tmp/$k.txt $i/$j/scores.txt > /tmp/$j.txt
	done
	gawk '{print $1"\t"($2+$3+$4+$5+$6+$7+$8+$9+$10+$11)/10}' /tmp/$j.txt > rmsescores/$i\_scores.txt
	#rm /tmp/*.txt
	sort -nk2 rmsescores/$i\_scores.txt | head -1 | gawk 'BEGIN {print "'"$i"'"} END {print $2"\t"$1}' >> rmsesummary.txt
done
sed -i ':a;N;$!ba;s/\n/\t/g' rmsesummary.txt
sed -i 's/.json\t/\n/g' rmsesummary.txt
