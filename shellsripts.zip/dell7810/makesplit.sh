#!/bin/sh

split=$1

/bin/rm train.[fn] test.[fn] atm_bond.pl two_dim.pl train_classes.pl test_classes.pl

ln -s $split/train.pl train_classes.pl

ln -s $split/test.pl test_classes.pl

ln -s $split/ab.pl atm_bond.pl
ln -s  $split/fr.pl two_dim.pl
