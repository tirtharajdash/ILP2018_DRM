#!/bin/bash

#AIM: Create target directory for the csv files. Each csv file is a target qsar problem. Under each target there are many chembl compounds.

for file in *.csv
do
    #if [ -d `basename $file .csv` ]
    #then
    #    rm -r `basename $file .csv`
    #fi

    #if [ ! -d `basename $file .csv` ]
    #then
    #    mkdir -p `basename $file .csv`;
    #    cat $file | while read line; do cp ./../pl_files/"$line.pl" ./`basename $file .csv`/"$line.pl"; done;
    #fi
    
    countd=$(find `basename $file .csv`/ -maxdepth 1 -name '*.pl' | wc -l);
    countf=$(cat $file | wc -l);
    
    if [ $countd -eq $countf ]
    then
	    cat $file | while read line; do sed -i "s/\*\*\*\*\*/${line}/g" ./`basename $file .csv`/$line.pl; done
	    cat $file | while read line; do cat `basename $file .csv`_problem.tsv | grep $line | gawk '{print "target('"'"'" $1 "'"'"')."}' >> ./`basename $file .csv`/$line.pl; done
	    cat $file | while read line; do cat `basename $file .csv`_problem.tsv | grep $line | gawk '{print "compound_id('"'"'" $2 "'"'"')."}' >> ./`basename $file .csv`/$line.pl; done
	    cat $file | while read line; do cat `basename $file .csv`_problem.tsv | grep $line | gawk '{print "activity('\'${line}\'',",$3")."}' >> ./`basename $file .csv`/$line.pl; done
        echo `basename $file .csv` "(prepared)"
    else
	    rm -r `basename $file .csv`
	    rm $file
	    rm `basename $file .csv`_problem.tsv
    fi
done
