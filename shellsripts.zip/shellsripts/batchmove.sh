for file in *.mol
do
    echo $file
    mv $file ./../allmol/
done
