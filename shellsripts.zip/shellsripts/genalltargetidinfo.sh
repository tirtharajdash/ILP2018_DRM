#Note: You have to copy the command and paste it into the terminal to run it. I didn't have time to cure it.

#cat ChEMBL17_bioactivity_export.tsv | while IFS=$'\t' read f1 f2 f3 f4 f5 f6 f7 f8; do echo $f4,$f6,$f7; done;
 
#cat ChEMBL17_bioactivity_export.tsv | while IFS=$'\t' read f1 f2 f3 f4 f5 f6 f7 f8; do echo $f6 >> alltargets/$f4.csv; done;


cat ChEMBL17_bioactivity_export.tsv | while IFS=$'\t' read f1 f2 f3 f4 f5 f6 f7 f8; do echo $f1 $f2 $f6 >> alltargets/$f4_target.csv; done;


#wc -l * | sort -u
