for file in *.mol.mol2; 
do
    mv "$file" "$(basename "$file" .mol.mol2)"
done
