#!/bin/sh

#cat HomoSapiensFiles | while read line; do cp ./mol_files/$line.mol ./HomoSapiens/mol/; done

#cat HomoSapiensFiles | while read line; do babel -imol ./HomoSapiens/mol/$line.mol -omol2 ./HomoSapiens/mol2/$line -h; done

#cat HomoSapiensFiles | while read line; do cat ./HomoSapiens/mol2/$line | ./newmol2pl A > ./HomoSapiens/pl/$line.pl; done 

cat HomoSapiensFiles | while read line; do sed -i "s/\*\*\*\*\*/${line}/g" ./HomoSapiens/pl/$line.pl; done

cat HomoSapiensFiles | while read line; do cat HomoSapiensProblem | grep $line | gawk '{print "target('"'"'" $5 "'"'"')."}' >> ./HomoSapiens/pl/$line.pl; done
cat HomoSapiensFiles | while read line; do cat HomoSapiensProblem | grep $line | gawk '{print "compound_id('"'"'" $7 "'"'"')."}' >> ./HomoSapiens/pl/$line.pl; done
cat HomoSapiensFiles | while read line; do cat HomoSapiensProblem | grep $line | gawk '{print "activity('\'${line}\'',",$8")."}' >> ./HomoSapiens/pl/$line.pl; done

