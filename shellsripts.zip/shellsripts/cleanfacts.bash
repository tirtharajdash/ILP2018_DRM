#!/bin/bash

for d in 1 2 3 4 5 6 7 8 9 10
do	
	sed -i "s/activity('CHEMBL39', 7.824).//g" $d/*.pl
	sed -i "s/activity('CHEMBL39', 7.699).//g" $d/*.pl
	sed -i "s/activity('CHEMBL39', 4.602).//g" $d/*.pl
	sed -i "s/activity('CHEMBL39', 8.155).//g" $d/*.pl
	sed -i "s/activity('CHEMBL86', 7.509).//g" $d/*.pl
	sed -i "s/activity('CHEMBL86', 6.745).//g" $d/*.pl
	sed -i "s/activity('CHEMBL86', 6.936).//g" $d/*.pl
	sed -i "/^$/d" $d/*.pl
done
